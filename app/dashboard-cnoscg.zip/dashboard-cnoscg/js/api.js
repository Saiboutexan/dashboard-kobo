const KOBO_CONFIG = {

  url: "https://script.google.com/macros/s/AKfycbwlIOdUDN3DpTf1knduCgLNXu8aitb1xKTd8fq30wdVi7xo9pibJA6b5YXAdFgB1tA/exec"

};

// ======================================
// CONNEXION KOBO
// ======================================

async function connectKobo() {

  try {

    console.log(
      "🔄 Connexion Proxy Kobo..."
    );

    const response =
      await fetch(
        KOBO_CONFIG.url,
        {
          method:"GET",
          cache:"no-cache"
        }
      );

    console.log(response);

    if (!response.ok) {

      throw new Error(
        "Erreur HTTP : " +
        response.status
      );

    }

    const data =
      await response.json();

    console.log(
      "📦 DATA KOBO :",
      data
    );

    // =========================
    // VERIFICATION
    // =========================

    if(!data){

      throw new Error(
        "Aucune donnée reçue"
      );

    }

    // =========================
    // RESULTS
    // =========================

    const records =
      data.results || [];

    console.log(
      "📊 Nombre enregistrements :",
      records.length
    );

    if(records.length === 0){

      console.warn(
        "⚠️ Aucune donnée Kobo."
      );

      return;
    }

    // =========================
    // DASHBOARD
    // =========================

    processData(records);

    console.log(
      "✅ Dashboard mis à jour"
    );

  } catch (error) {

    console.error(
      "❌ ERREUR API :",
      error
    );

    alert(
      "Erreur Proxy API : " +
      error.message
    );

  }

}

// ======================================
// DEMARRAGE AUTOMATIQUE
// ======================================

window.addEventListener(
  "DOMContentLoaded",
  () => {

    connectKobo();

    startRealtime();

  }
);